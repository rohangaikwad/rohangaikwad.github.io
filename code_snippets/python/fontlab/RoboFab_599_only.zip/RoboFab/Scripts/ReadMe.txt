RoboFab Scripts

These are some folders with scripts that can be run in FontLab.