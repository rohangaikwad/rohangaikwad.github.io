"""This is a test module so we can see if we can install and import this without messing up the actual modules we need to work with."""
version = "1.0"