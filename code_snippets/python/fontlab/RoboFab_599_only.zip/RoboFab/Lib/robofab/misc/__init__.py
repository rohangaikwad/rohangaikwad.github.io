"""

    arrayTools and bezierTools, originally from fontTools and using Numpy,
    now in a pure python implementation. This should ease the Numpy dependency
    for normal UFO input/output and basic scripting tasks.
    
    comparison test and speedtest provided.

"""




