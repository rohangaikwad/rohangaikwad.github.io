"""

Directory for modules
which do path stuff.
Maybe it should move somewhere else.


"""




