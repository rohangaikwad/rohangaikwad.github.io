"""

Directory for all tool like code.
Stuff that doesn't really belong to objects, pens, compilers etc.
The code is split up into sections.


"""




