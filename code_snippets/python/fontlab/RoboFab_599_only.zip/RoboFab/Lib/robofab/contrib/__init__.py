"""

Directory for contributed packages.
Packages stored here can be imported from
	robofab.contrib.<packagename>

"""




